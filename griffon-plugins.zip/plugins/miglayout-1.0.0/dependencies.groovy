griffon.project.dependency.resolution = {
    inherits "global"
    log "warn"
    repositories {
        //griffonHome()
        //mavenCentral()
        mavenRepo 'https://repo1.maven.org/maven2'
        mavenRepo "https://download.java.net/maven/2/"        
        mavenRepo "https://mvnrepository.com/artefact"
        mavenRepo "https://repository.jboss.org/nexus/content/groups/public/"
        mavenRepo "https://maven.java.net/content/repositories/public/"
        mavenRepo 'https://github.com/mobilemindtec/m2/raw/master'
        
    }
    dependencies {
        compile 'com.miglayout:miglayout-swing:4.2'
    }
}

log4j = {
    appenders {
        console name: 'stdout', layout: pattern(conversionPattern: '%d [%t] %-5p %c - %m%n')
    }

    error 'org.codehaus.griffon',
          'org.springframework',
          'org.apache.karaf',
          'groovyx.net'
    warn  'griffon'
}