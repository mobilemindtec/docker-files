griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin miglayout-1.0.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-miglayout-runtime', version: '1.0.0')
        
    }
}