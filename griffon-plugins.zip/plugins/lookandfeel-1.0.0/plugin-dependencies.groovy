griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin lookandfeel-1.0.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-lookandfeel-runtime', version: '1.0.0')
        test(group: 'org.codehaus.griffon.plugins', name: 'griffon-lookandfeel-test', version: '1.0.0')
    }
}