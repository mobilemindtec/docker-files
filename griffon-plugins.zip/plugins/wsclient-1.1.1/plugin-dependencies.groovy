griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin wsclient-1.1.1', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-wsclient-runtime', version: '1.1.1')
	build(group: 'org.codehaus.griffon.plugins', name: 'griffon-wsclient-compile', version: '1.1.1')
        
    }
}