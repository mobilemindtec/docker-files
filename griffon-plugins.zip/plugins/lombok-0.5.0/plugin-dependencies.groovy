griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin lombok-0.5.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        build(group: 'org.codehaus.griffon.plugins', name: 'griffon-lombok-compile', version: '0.5.0')
        
    }
}