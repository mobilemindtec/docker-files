griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin gsql-1.2.1', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-gsql-runtime', version: '1.2.1')
        
    }
}