griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin glazedlists-2.0.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-glazedlists-runtime', version: '2.0.0')
        
    }
}