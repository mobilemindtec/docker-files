### Building

This project requires all of its dependencies be available from maven compatible repositories.
Some of these dependencies have not been pushed to the Maven Central Repository, however you
can obtain them from [lombok-dev-deps][1].

Follow the instructions found there to install the required dependencies into your local Maven
repository before attempting to build this plugin.

[1]: https://github.com/aalmiray/lombok-dev-deps