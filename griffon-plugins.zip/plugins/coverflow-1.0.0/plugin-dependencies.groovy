griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin coverflow-1.0.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-coverflow-runtime', version: '1.0.0')
        
    }
}