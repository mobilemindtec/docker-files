griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin swing-1.3.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-swing-runtime', version: '1.3.0')
	build(group: 'org.codehaus.griffon.plugins', name: 'griffon-swing-compile', version: '1.3.0')
        
    }
}