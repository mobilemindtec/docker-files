griffon.project.dependency.resolution = {
    repositories {
        flatDir(name: 'plugin datasource-1.3.0', dirs: [
            "${pluginDirPath}/dist"
        ])
    }
    dependencies {
        compile(group: 'org.codehaus.griffon.plugins', name: 'griffon-datasource-runtime', version: '1.3.0')
	build(group: 'org.codehaus.griffon.plugins', name: 'griffon-datasource-compile', version: '1.3.0')
        
    }
}